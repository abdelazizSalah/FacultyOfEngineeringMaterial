# RSA 

### Getting started
1. clone the repo or unzip the files
2. go the the location where you have installed files
> cd "(PATH)"

## Run the receiver first
> python receiver.py

## Enter number of bits you want to generate the RSA pair keys
- it must be greater than 20

## Run the sender
> python sender.py

## Start chatting :D 

## now lets do the attack
> python attack.py
- as the number of bits increases the attack time will exponentially increases. 


## link for video explaination
>   https://www.youtube.com/watch?v=lZgaZK_KBXk