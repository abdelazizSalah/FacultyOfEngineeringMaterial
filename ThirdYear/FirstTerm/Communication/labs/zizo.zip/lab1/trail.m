x = 10; 
y = 11; 
z = x + y